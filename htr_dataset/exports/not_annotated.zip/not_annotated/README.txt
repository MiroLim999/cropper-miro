Type the word of every image in the 'text' column of labels_template.csv (or .xlsx).
Write 'unreadable' in the 'status' column for an image that cannot be read.
Then use 'Import annotated file' in the Word Cropper to merge the labels back (matched by the uid column, so it never mixes up datasets; keep that column).
